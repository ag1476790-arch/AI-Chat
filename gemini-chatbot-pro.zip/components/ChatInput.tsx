
import React, { useState, useRef, useEffect } from 'react';

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  disabled: boolean;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, disabled }) => {
  const [input, setInput] = useState('');
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    if (input.trim() && !disabled) {
      onSendMessage(input.trim());
      setInput('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 150)}px`;
    }
  }, [input]);

  return (
    <div className="p-4 bg-slate-900/80 backdrop-blur-md border-t border-slate-800">
      <div className="max-w-4xl mx-auto relative flex items-end gap-2">
        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask me anything..."
            disabled={disabled}
            className="w-full bg-slate-800 text-slate-100 rounded-2xl py-3 px-4 pr-12 focus:outline-none focus:ring-2 focus:ring-indigo-500 border border-slate-700 resize-none custom-scrollbar disabled:opacity-50 transition-all"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || disabled}
            className="absolute right-2 bottom-2 p-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-500 text-white rounded-xl transition-colors w-8 h-8 flex items-center justify-center"
          >
            <i className="fas fa-paper-plane text-xs"></i>
          </button>
        </div>
      </div>
      <p className="text-[10px] text-center text-slate-500 mt-2">
        Gemini Chatbot Pro can make mistakes. Check important info.
      </p>
    </div>
  );
};

export default ChatInput;
