
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Message } from "../types";

// Note: process.env.API_KEY is pre-configured in the environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const streamChatResponse = async (
  messages: Message[],
  onChunk: (text: string) => void
) => {
  try {
    const history = messages.slice(0, -1).map(msg => ({
      role: msg.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: msg.content }]
    }));

    const lastMessage = messages[messages.length - 1].content;

    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: "You are a highly intelligent, helpful, and concise AI assistant. Format your responses using Markdown when appropriate (e.g., code blocks, bold text, lists).",
      }
    });

    // Re-create history for the chat instance if needed, 
    // but for simplicity with the current SDK version we use generateContentStream directly 
    // for robust handling if chat history objects are complex.
    
    const responseStream = await ai.models.generateContentStream({
      model: 'gemini-3-flash-preview',
      contents: [
        ...history,
        { role: 'user', parts: [{ text: lastMessage }] }
      ]
    });

    let fullText = "";
    for await (const chunk of responseStream) {
      const textChunk = chunk.text;
      if (textChunk) {
        fullText += textChunk;
        onChunk(textChunk);
      }
    }
    
    return fullText;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};
